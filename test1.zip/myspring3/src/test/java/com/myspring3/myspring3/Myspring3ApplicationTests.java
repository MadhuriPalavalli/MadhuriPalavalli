package com.myspring3.myspring3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myspring3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
