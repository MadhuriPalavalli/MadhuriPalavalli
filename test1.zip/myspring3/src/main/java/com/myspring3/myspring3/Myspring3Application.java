package com.myspring3.myspring3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myspring3Application {

	public static void main(String[] args) {
		SpringApplication.run(Myspring3Application.class, args);
	}

}
