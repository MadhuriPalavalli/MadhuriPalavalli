package com.myspring3.myspring3;

import java.util.List;

public interface IProductService {

	List<Product> findAll();

}
